using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour
{
    // Start is called before the first frame update
    /*
    GameObject a;
    int b = 2;
    void Start()
    {
        a = GameObject.Find("Canvas");
    }

    // Update is called once per frame
    void Update()
    {
        if()
        {
            a.transform.Find("Panel").gameObject.SetActive(true);
        }
    }
    */
}
